var StableFlotr = Flotr.noConflict();
