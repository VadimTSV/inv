<?php

$dblogin = 'invuser';
$dbpass = 'invpass';

global $idb;
global $InvDBName; 
$InvDBName = 'invcollector';
try {
    $idb = new PDO('mysql:host=localhost;dbname='.$InvDBName, $dblogin, 
    $dbpass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8", 
    PDO::ATTR_PERSISTENT => true));
} catch( PDOException $Exception ) {
    echo 'error: ';
    echo $Exception->getMessage();
    exit;
}


