<?php
echo 'server_status_ok';
